# Print the greeting below
